---
name: supplier-review
description: Review supplied contractual and delivery evidence.
---

# Supplier review

Compare contractual obligations with delivery records and explain discrepancies.
